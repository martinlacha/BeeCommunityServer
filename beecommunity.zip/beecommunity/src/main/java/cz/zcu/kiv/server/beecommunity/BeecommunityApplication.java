package cz.zcu.kiv.server.beecommunity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BeecommunityApplication {

	public static void main(String[] args) {
		SpringApplication.run(BeecommunityApplication.class, args);
	}

}
