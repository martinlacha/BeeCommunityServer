package cz.zcu.kiv.server.beecommunity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeecommunityApplicationTests {

	@Test
	void contextLoads() {
	}

}
